package lab.aikibo.cobacrudangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobaCrudAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(CobaCrudAngularApplication.class, args);
	}
}
