package lab.aikibo.cobaspringweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobaSpringWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CobaSpringWebApplication.class, args);
	}
}
